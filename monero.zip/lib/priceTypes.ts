// src/lib/priceTypes.ts

// A simple map: CoinGecko ID -> USD price
export type PriceMap = Record<string, number>;
